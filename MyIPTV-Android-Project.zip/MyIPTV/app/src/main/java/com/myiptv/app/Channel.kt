package com.myiptv.app
data class Channel(val name: String, val url: String, val group: String = "غير مصنف")
