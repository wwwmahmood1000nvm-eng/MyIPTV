package com.myiptv.app
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {
 private val repo = IptvRepository()
 private var channels: List<Channel> = emptyList()
 private lateinit var adapter: ChannelAdapter
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState); setContentView(R.layout.activity_main)
  val m3u = findViewById<RadioButton>(R.id.m3uRadio)
  val xtream = findViewById<RadioButton>(R.id.xtreamRadio)
  val url = findViewById<EditText>(R.id.urlInput)
  val user = findViewById<EditText>(R.id.userInput)
  val pass = findViewById<EditText>(R.id.passInput)
  val button = findViewById<Button>(R.id.addButton)
  val status = findViewById<TextView>(R.id.statusText)
  val search = findViewById<EditText>(R.id.searchInput)
  val list = findViewById<RecyclerView>(R.id.channelList)
  fun mode() {
   val x = xtream.isChecked
   user.visibility = if (x) View.VISIBLE else View.GONE
   pass.visibility = if (x) View.VISIBLE else View.GONE
   url.hint = if (x) "عنوان خادم Xtream مثل https://server.example:8080" else "رابط قائمة M3U / M3U8"
  }
  m3u.setOnClickListener { mode() }; xtream.setOnClickListener { mode() }
  adapter = ChannelAdapter(emptyList()) { c ->
   startActivity(Intent(this, PlayerActivity::class.java).putExtra("url", c.url).putExtra("name", c.name))
  }
  list.layoutManager = LinearLayoutManager(this); list.adapter = adapter
  button.setOnClickListener {
   button.isEnabled = false; status.text = "جارٍ تحميل القنوات..."
   lifecycleScope.launch {
    try {
     channels = if (xtream.isChecked) repo.loadXtream(url.text.toString(), user.text.toString(), pass.text.toString())
      else repo.loadM3u(url.text.toString())
     adapter.submit(channels); status.text = "تم تحميل ${channels.size} قناة مباشرة"
    } catch (e: Exception) { status.text = e.message ?: "تعذر تحميل القنوات" }
    finally { button.isEnabled = true }
   }
  }
  search.addTextChangedListener(object: android.text.TextWatcher {
   override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
   override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
    val q = s.toString().trim()
    adapter.submit(channels.filter { it.name.contains(q, true) || it.group.contains(q, true) })
   }
   override fun afterTextChanged(s: android.text.Editable?) {}
  })
  mode()
 }
}
