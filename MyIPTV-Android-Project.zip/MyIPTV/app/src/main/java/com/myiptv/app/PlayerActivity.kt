package com.myiptv.app
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

class PlayerActivity : AppCompatActivity() {
 private var player: ExoPlayer? = null
 override fun onCreate(savedInstanceState: Bundle?) {
  super.onCreate(savedInstanceState); setContentView(R.layout.activity_player)
  title = intent.getStringExtra("name") ?: "My IPTV"
  val stream = intent.getStringExtra("url") ?: run { finish(); return }
  val view = findViewById<PlayerView>(R.id.playerView)
  player = ExoPlayer.Builder(this).build().also {
   view.player = it; it.setMediaItem(MediaItem.fromUri(stream)); it.prepare(); it.playWhenReady = true
  }
 }
 override fun onStop() { super.onStop(); player?.pause() }
 override fun onDestroy() { player?.release(); player = null; super.onDestroy() }
}
