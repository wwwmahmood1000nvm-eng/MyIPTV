package com.myiptv.app
object M3uParser {
 fun parse(content: String): List<Channel> {
  val result = mutableListOf<Channel>()
  var name = ""; var group = "غير مصنف"
  content.lineSequence().forEach { raw ->
   val line = raw.trim()
   when {
    line.startsWith("#EXTINF", true) -> {
     name = line.substringAfterLast(',').trim().ifBlank { "قناة بدون اسم" }
     group = Regex("""group-title="([^"]*)""").find(line)?.groupValues?.get(1) ?: "غير مصنف"
    }
    line.startsWith("http://", true) || line.startsWith("https://", true) -> {
     result += Channel(name.ifBlank { line }, line, group); name = ""; group = "غير مصنف"
    }
   }
  }
  return result
 }
}
