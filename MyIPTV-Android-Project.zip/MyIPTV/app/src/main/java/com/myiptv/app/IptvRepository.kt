package com.myiptv.app
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

class IptvRepository {
 private val client = OkHttpClient.Builder().connectTimeout(20, TimeUnit.SECONDS)
  .readTimeout(45, TimeUnit.SECONDS).build()
 private suspend fun get(url: String): String = withContext(Dispatchers.IO) {
  val req = Request.Builder().url(url).header("User-Agent", "MyIPTV/1.0").build()
  client.newCall(req).execute().use { r ->
   if (!r.isSuccessful) error("فشل الاتصال: HTTP ${r.code}")
   r.body?.string() ?: error("استجابة فارغة")
  }
 }
 suspend fun loadM3u(url: String): List<Channel> {
  require(url.startsWith("https://") || url.startsWith("http://")) { "أدخل رابطاً صحيحاً" }
  return M3uParser.parse(get(url)).also { if (it.isEmpty()) error("القائمة لا تحتوي قنوات") }
 }
 suspend fun loadXtream(server: String, username: String, password: String): List<Channel> {
  require(username.isNotBlank() && password.isNotBlank()) { "أدخل اسم المستخدم وكلمة المرور" }
  val base = server.trim().trimEnd('/')
  require(base.startsWith("https://") || base.startsWith("http://")) { "عنوان الخادم غير صحيح" }
  val u = URLEncoder.encode(username, "UTF-8"); val p = URLEncoder.encode(password, "UTF-8")
  val api = "$base/player_api.php?username=$u&password=$p"
  val auth = JSONObject(get(api))
  if (auth.optJSONObject("user_info")?.optString("auth") == "0") error("بيانات الدخول غير صحيحة")
  val arr = JSONArray(get("$api&action=get_live_streams"))
  val out = mutableListOf<Channel>()
  for (i in 0 until arr.length()) {
   val item = arr.getJSONObject(i); val id = item.optString("stream_id")
   if (id.isBlank()) continue
   val ext = item.optString("container_extension").ifBlank { "ts" }
   out += Channel(item.optString("name", "Channel $id"), "$base/live/$u/$p/$id.$ext",
    item.optString("category_name", "قنوات مباشرة"))
  }
  if (out.isEmpty()) error("لم يتم العثور على قنوات مباشرة")
  return out
 }
}
