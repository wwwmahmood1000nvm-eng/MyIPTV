package com.myiptv.app
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ChannelAdapter(private var items: List<Channel>, private val onClick: (Channel) -> Unit)
 : RecyclerView.Adapter<ChannelAdapter.Holder>() {
 class Holder(v: View): RecyclerView.ViewHolder(v) {
  val name: TextView = v.findViewById(R.id.channelName)
  val meta: TextView = v.findViewById(R.id.channelMeta)
 }
 override fun onCreateViewHolder(parent: ViewGroup, type: Int) =
  Holder(LayoutInflater.from(parent.context).inflate(R.layout.row_channel, parent, false))
 override fun getItemCount() = items.size
 override fun onBindViewHolder(h: Holder, pos: Int) {
  val c = items[pos]; h.name.text = c.name; h.meta.text = c.group
  h.itemView.setOnClickListener { onClick(c) }
 }
 fun submit(data: List<Channel>) { items = data; notifyDataSetChanged() }
}
